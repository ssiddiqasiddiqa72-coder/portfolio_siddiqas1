Place your resume PDF here as:

  Siddiqa-Resume.pdf

This file is linked from the "Download Resume" buttons on the portfolio website.
